.. XRSTools documentation master file, created by
   sphinx-quickstart on Mon Nov  3 15:21:20 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to XRSTools's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 4

.. automodule:: xrstools

.. autoclass:: xrstools.xrs_read
    :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

